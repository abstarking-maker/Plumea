# Plumea – Professional Android App

**Version 1.1.0** · Gentle, safe weight tracking companion.

Hybrid architecture: modern native Android shell (Kotlin + Material 3 + SplashScreen + Edge-to-Edge) hosting a fully offline HTML/JS experience. Optional Supabase backend for anonymous referrals, group challenges and AI meal photo analysis.

## Features
- Personal calorie goal from age, height, weight
- Quick meal logging + custom entries
- Water tracker & joint-friendly movement
- Daily check-in, daily challenge, streaks, levels & badges
- Weight chart, 7-day summary, week-over-week comparison
- **Reliable daily reminder** (exact alarm when permitted, survives reboot)
- 8 languages (EN, AR, ES, FR, PT-BR, TR, RU, HI) with full RTL
- Works completely offline – health data never leaves the device
- Optional cloud: referral codes, group challenges, AI calorie estimation from photo
- Share progress card as image
- Professional Splash Screen, Edge-to-Edge, Dark Mode, Haptic feedback

## Architecture (v1.1)
| Layer | Technology |
|-------|------------|
| UI shell | Kotlin, ComponentActivity, Material 3, SplashScreen API |
| Content | Single-page HTML/JS (assets/www) with localStorage |
| Bridge | AndroidBridge (reminder, share, permissions, haptic, version) |
| Notifications | NotificationCompat + exact AlarmManager + BootReceiver |
| Backend (optional) | Supabase (anonymous auth) + Anthropic Claude for meal scan |

## Requirements
- Android Studio Ladybug / Koala or newer
- JDK 17
- minSdk 26 (Android 8.0) · targetSdk 35 (Android 15)

## Run
1. Open the `Plumea-Android` folder in Android Studio.
2. Let Gradle sync.
3. Connect a device or start an emulator → Run.

Package: `com.plumea.app`  
Change it in `app/build.gradle.kts` **before** publishing (cannot be changed later).

## Before publishing on Google Play
1. Generate a signed App Bundle (AAB). Store the keystore securely in two places.
2. Upload AAB to Play Console.
3. Complete Data safety form:
   - If backend is enabled: anonymous ID, challenge nickname/score, meal photos sent for analysis (not stored).
   - Health data stays on device.
4. Publish privacy policy (`store/privacy-policy.md`) to a public HTTPS URL.
5. Screenshots: take from a real device (light + dark if possible).
6. Store listing texts are ready in `store/listing.md` (8 languages).
7. Content rating: Health & Fitness. Not a medical device – keep the in-app medical disclaimer.

## Optional Backend
See `Plumea-Backend/BACKEND_README.md`.  
Set credentials in `app/src/main/assets/www/config.js`:
```js
window.PLUMEA = { url: "https://YOUR_REF.supabase.co", key: "YOUR_ANON_KEY" };
```
Leave empty to hide community & AI scan features.

## Technical notes
- Reminder uses exact alarms when the user grants `SCHEDULE_EXACT_ALARM` (Android 12+). Otherwise falls back gracefully.
- Notification permission is requested only when the user enables a reminder (Android 13+).
- Health data lives in WebView localStorage. Clearing app data or uninstalling removes it. Cloud backup of health data is intentionally not enabled.
- ProGuard / R8 is enabled for release builds.
- Edge-to-edge + proper WindowInsets for modern devices and display cutouts.

## Changelog
### 1.1.0
- Modern native shell (Material 3, SplashScreen, Edge-to-Edge)
- Reliable exact-alarm reminders + re-schedule after reboot / time change
- Improved WebView security & file chooser
- Haptic feedback, app version bridge
- Network security config, backup exclusion rules
- Professional themes (light / dark)
- Build configuration for global release readiness

### 1.0
- Initial hybrid release
