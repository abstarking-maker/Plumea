# Plumea ProGuard / R8 rules

# Keep JS bridge methods
-keepclassmembers class com.plumea.app.MainActivity$Bridge {
    @android.webkit.JavascriptInterface <methods>;
}

# WebView
-keepclassmembers class * extends android.webkit.WebViewClient {
    public void *(android.webkit.WebView, java.lang.String, android.graphics.Bitmap);
    public boolean *(android.webkit.WebView, java.lang.String);
}
-keepclassmembers class * extends android.webkit.WebChromeClient {
    public void *(android.webkit.WebView, java.lang.String, android.webkit.JsResult);
    public boolean *(android.webkit.WebView, *...);
}

# Keep BroadcastReceivers
-keep class com.plumea.app.ReminderReceiver { *; }
-keep class com.plumea.app.BootReceiver { *; }

# Kotlin
-dontwarn kotlin.**
-keep class kotlin.Metadata { *; }

# Material / AndroidX
-dontwarn com.google.android.material.**
-keep class com.google.android.material.** { *; }
