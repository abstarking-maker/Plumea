package com.plumea.app

import android.app.Application

/**
 * Application class – creates notification channel early and prepares global state.
 */
class PlumeaApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Reminder.ensureChannel(this)
    }
}
