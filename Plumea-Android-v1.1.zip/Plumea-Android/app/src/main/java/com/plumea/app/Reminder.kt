package com.plumea.app

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import java.util.Calendar

/**
 * Reliable daily reminder using AlarmManager.
 * Uses setExactAndAllowWhileIdle when possible (Android 12+ exact alarm permission aware).
 * Survives reboot via BootReceiver.
 */
object Reminder {
    private const val PREFS = "plumea_reminder"
    private const val CHANNEL_ID = "daily_reminder"
    private const val NOTIF_ID = 1001
    private const val REQUEST_CODE = 42

    fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = context.getSystemService(NotificationManager::class.java)
            val channel = NotificationChannel(
                CHANNEL_ID,
                context.getString(R.string.notif_channel_name),
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = context.getString(R.string.notif_channel_desc)
                setShowBadge(true)
            }
            nm.createNotificationChannel(channel)
        }
    }

    private fun pendingIntent(context: Context, title: String, body: String): PendingIntent {
        val intent = Intent(context, ReminderReceiver::class.java).apply {
            putExtra("title", title)
            putExtra("body", body)
        }
        return PendingIntent.getBroadcast(
            context,
            REQUEST_CODE,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun schedule(context: Context, hm: String, title: String, body: String) {
        ensureChannel(context)
        val am = context.getSystemService(AlarmManager::class.java) ?: return
        val pi = pendingIntent(context, title, body)
        am.cancel(pi)

        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString("hm", hm)
            .putString("title", title)
            .putString("body", body)
            .putBoolean("enabled", true)
            .apply()

        val match = Regex("""(\d{1,2}):(\d{2})""").matchEntire(hm.trim()) ?: return
        val hour = match.groupValues[1].toInt().coerceIn(0, 23)
        val minute = match.groupValues[2].toInt().coerceIn(0, 59)

        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) {
                add(Calendar.DAY_OF_YEAR, 1)
            }
        }

        val triggerAt = cal.timeInMillis
        try {
            when {
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
                    if (am.canScheduleExactAlarms()) {
                        am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)
                    } else {
                        // Fallback – still reliable enough for daily gentle reminder
                        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)
                    }
                }
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.M -> {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)
                }
                else -> {
                    am.setExact(AlarmManager.RTC_WAKEUP, triggerAt, pi)
                }
            }
        } catch (_: SecurityException) {
            // Exact alarm not granted – degrade gracefully
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)
        }
    }

    fun cancel(context: Context) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val title = prefs.getString("title", "") ?: ""
        val body = prefs.getString("body", "") ?: ""
        val am = context.getSystemService(AlarmManager::class.java)
        am?.cancel(pendingIntent(context, title, body))
        prefs.edit().putBoolean("enabled", false).apply()
    }

    fun rescheduleFromPrefs(context: Context) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (!prefs.getBoolean("enabled", false)) return
        val hm = prefs.getString("hm", null) ?: return
        val title = prefs.getString("title", context.getString(R.string.notif_default_title))
            ?: context.getString(R.string.notif_default_title)
        val body = prefs.getString("body", context.getString(R.string.notif_default_body))
            ?: context.getString(R.string.notif_default_body)
        schedule(context, hm, title, body)
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Reminder.ensureChannel(context)

        val title = intent.getStringExtra("title")
            ?: context.getString(R.string.notif_default_title)
        val body = intent.getStringExtra("body")
            ?: context.getString(R.string.notif_default_body)

        val openIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val contentPi = PendingIntent.getActivity(
            context,
            1,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, "daily_reminder")
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setContentIntent(contentPi)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .build()

        try {
            NotificationManagerCompat.from(context).notify(1001, notification)
        } catch (_: SecurityException) {
            // POST_NOTIFICATIONS not granted
        }

        // Re-schedule the next day (exact alarms are one-shot)
        Reminder.rescheduleFromPrefs(context)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED ||
            intent.action == Intent.ACTION_MY_PACKAGE_REPLACED ||
            intent.action == Intent.ACTION_TIME_CHANGED ||
            intent.action == Intent.ACTION_TIMEZONE_CHANGED
        ) {
            Reminder.rescheduleFromPrefs(context)
        }
    }
}
