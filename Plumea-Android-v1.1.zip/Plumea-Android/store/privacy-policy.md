# Privacy Policy – Plumea

**Last updated: 19 October 2026**

Plumea (“we”, “the app”) is designed with privacy as a core principle. This policy explains what data is processed and how.

## 1. Data stored only on your device
The following information is stored **exclusively on your device** using the app’s local storage and is **never uploaded** to our servers:

- Nickname or name you choose  
- Age, sex, height, weight history  
- Meals, water intake, activity minutes  
- Daily check-ins, streaks, XP, badges, reminders  

Uninstalling the app or clearing its data permanently deletes this information. We do not have access to it.

## 2. Optional online features (anonymous)
If you enable the optional community features (or if the developer has configured a backend), the app uses an **automatic anonymous identifier**. No email, password or real name is required.

| Feature | What is processed | Retention |
|---------|-------------------|-----------|
| Referral code | Anonymous ID + referral code + count of invited friends | Until you delete cloud data |
| Group challenges | Anonymous ID, nickname you choose, weekly score (visible only to members of the same challenge) | Until you leave the challenge or delete cloud data |
| Meal photo analysis | The photo you select is sent once to Anthropic for calorie estimation and is **not stored** by Plumea | Transient (analysis only) |

## 3. Processors
- **Supabase** – hosts the anonymous identity, referral and challenge data.  
- **Anthropic** – analyses meal photos for calorie estimates (photo is not retained by Plumea after the response).

We do **not** sell data, we do **not** use advertising SDKs, and we do **not** use third-party analytics that track individuals.

## 4. Your rights and control
- Inside the app: **Community → Delete my cloud data** removes your anonymous identity and related records.  
- You may also request deletion by emailing the contact below.  
- Uninstalling the app removes all on-device data.

## 5. Children
Plumea is not directed at children under 13 (or the applicable age in your country). We do not knowingly collect data from children.

## 6. Medical disclaimer
Plumea is a tracking and educational tool only. It is **not a medical device** and does not provide medical advice. Consult a qualified healthcare professional before making significant changes to diet or activity, especially if you have diabetes, hypertension, heart or joint conditions, or are under 18 / pregnant / breastfeeding.

## 7. Changes
We may update this policy. The “Last updated” date will change. Continued use of the app after changes constitutes acceptance.

## 8. Contact
For privacy questions or deletion requests:  
**[YOUR EMAIL]**  
Web deletion form (if published): **[WEB DELETION URL]**
