# Google Play Store Listing – Plumea

> Avoid promises of rapid weight loss or guaranteed numbers. Google’s health-app policy is strict.

## English (en-US)
**Title** (≤ 30 chars): Plumea: Gentle Weight Loss  
**Short description** (≤ 80): Gentle, safe weight tracking – calories, water, movement & daily motivation  
**Full description:**

Plumea is a gentle companion for people who want to lose weight at a safe, steady pace — without deprivation or harsh rules.

• Personal daily calorie goal based on your age, height and weight  
• Quick meal logging with common foods + custom entries  
• Water tracker and light, joint-friendly movement that grows weekly  
• Daily check-in, daily challenge, streaks, levels and badges  
• Weight chart, 7-day summary and week-over-week comparison  
• Reliable daily reminder at the time you choose  
• 8 languages: English, Arabic, Spanish, French, Portuguese (Brazil), Turkish, Russian, Hindi  
• Works fully offline. Your health data stays on your device.  
• Optional: share a progress card, join friendly group challenges, or estimate calories from a meal photo

Plumea is for tracking and education only and does **not** replace a doctor or dietitian. If you have diabetes, high blood pressure, heart or joint conditions, are pregnant or under 18, talk to a healthcare professional first.

## العربية (ar)
**العنوان:** Plumea: رشاقة بلطف  
**الوصف القصير:** تخسيس آمن وتدريجي: سعرات، ماء، حركة وتحفيز يومي بلا حرمان  
**الوصف الكامل:**

Plumea رفيق لطيف لمن يريد إنقاص وزنه بوتيرة آمنة ومستقرة ودون حرمان.

• هدف سعرات يومي يناسب عمرك وطولك ووزنك  
• تسجيل سريع للوجبات الشائعة مع إمكانية الإضافة اليدوية  
• متابعة الماء وحركة لطيفة على المفاصل بهدف يرتفع أسبوعياً  
• تسجيل حضور يومي وتحدٍّ يومي وأيام متتالية ومستويات وشارات  
• رسم بياني للوزن وحصيلة 7 أيام ومقارنة الأسبوع بالأسبوع الماضي  
• تذكير يومي موثوق بالوقت الذي تختاره  
• 8 لغات، ويعمل دون إنترنت، وبياناتك الصحية تبقى على جهازك  
• اختياري: مشاركة بطاقة تقدمك، تحديات جماعية، أو تقدير السعرات من صورة الوجبة

التطبيق للمتابعة والتوعية ولا يغني عن الطبيب. مع السكري أو الضغط أو القلب أو المفاصل أو الحمل استشر مختصاً أولاً.

## Other languages (titles + short)
| Locale | Title | Short |
|--------|-------|-------|
| es | Plumea: Peso con suavidad | Control suave del peso: calorías, agua, movimiento y motivación diaria |
| fr | Plumea : perte de poids douce | Suivi doux du poids : calories, eau, activité et motivation au quotidien |
| pt-BR | Plumea: Emagreça com leveza | Acompanhamento gentil do peso: calorias, água, movimento e motivação diária |
| tr | Plumea: Nazik Kilo Takibi | Nazik kilo takibi: kalori, su, hareket ve günlük motivasyon |
| ru | Plumea: Мягкое похудение | Мягкий контроль веса: калории, вода, движение и ежедневная мотивация |
| hi | Plumea: सौम्य वज़न घटाना | सौम्य वज़न ट्रैकिंग: कैलोरी, पानी, गतिविधि और रोज़ की प्रेरणा |

> Have a native speaker review the full description for each language before publishing.
