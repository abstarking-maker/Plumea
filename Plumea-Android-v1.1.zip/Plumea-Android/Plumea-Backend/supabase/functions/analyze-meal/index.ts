// Supabase Edge Function: estimates calories from a meal photo. The AI key stays on the server.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const cors = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "authorization, apikey, content-type", "Access-Control-Allow-Methods": "POST, OPTIONS" };
const json = (o: unknown, s = 200) => new Response(JSON.stringify(o), { status: s, headers: { ...cors, "Content-Type": "application/json" } });

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  const sb = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
  const jwt = (req.headers.get("Authorization") || "").replace("Bearer ", "");
  const { data: { user } } = await sb.auth.getUser(jwt);
  if (!user) return json({ error: "auth" }, 401);

  const { image, lang } = await req.json().catch(() => ({}));
  if (typeof image !== "string" || image.length < 100 || image.length > 1_500_000) return json({ error: "image" }, 400);

  const { data: ok } = await sb.rpc("ai_bump", { uid: user.id, lim: Number(Deno.env.get("DAILY_LIMIT") || 5), glim: Number(Deno.env.get("GLOBAL_DAILY_LIMIT") || 500) });
  if (!ok) return json({ error: "limit" }, 429);

  const system = `You estimate calories of a meal from a photo. Reply with JSON only: {"items":[{"name":string,"kcal":integer}]}. ` +
    `List each visible food as served in the visible portion, at most 6 items, kcal rounded to the nearest 5, names short (max 30 chars) written in language code "${String(lang || "en").slice(0, 5)}". ` +
    `If there is no food in the photo return {"items":[]}. No commentary.`;
  const r = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "x-api-key": Deno.env.get("ANTHROPIC_API_KEY")!, "anthropic-version": "2023-06-01", "content-type": "application/json" },
    body: JSON.stringify({
      model: Deno.env.get("MODEL") || "claude-haiku-5-5", max_tokens: 500, system,
      messages: [{ role: "user", content: [{ type: "image", source: { type: "base64", media_type: "image/jpeg", data: image } }, { type: "text", text: "Estimate the calories." }] }],
    }),
  });
  if (!r.ok) return json({ error: "ai" }, 502);
  const out = await r.json();
  const text: string = out?.content?.[0]?.text || "";
  try {
    const p = JSON.parse(text.slice(text.indexOf("{"), text.lastIndexOf("}") + 1));
    const items = (Array.isArray(p.items) ? p.items : []).slice(0, 6).map((x: any) => ({
      name: String(x.name || "").slice(0, 40),
      kcal: Math.max(0, Math.min(2500, Math.round(Number(x.kcal) || 0))),
    })).filter((x: any) => x.name && x.kcal > 0);
    return json({ items });
  } catch { return json({ items: [] }); }
});
