-- Plumea backend (Supabase). Run once in SQL Editor.
-- No health data is stored here: only anonymous IDs, referral codes, challenge nickname/score and daily scan counters.
create table if not exists public.profiles(user_id uuid primary key references auth.users on delete cascade, ref_code text unique, referred_by uuid references auth.users on delete set null, created_at timestamptz default now());
create table if not exists public.challenges(id uuid primary key default gen_random_uuid(), code text unique not null, name text, owner uuid references auth.users on delete cascade, created_at timestamptz default now());
create table if not exists public.challenge_members(challenge_id uuid references public.challenges on delete cascade, user_id uuid references auth.users on delete cascade, name text, score int not null default 0, updated_at timestamptz default now(), primary key(challenge_id,user_id));
create table if not exists public.ai_usage(user_id uuid, day date, n int not null default 0, primary key(user_id,day));

-- Row Level Security: all tables locked; clients use only the functions below.
alter table public.profiles enable row level security;
alter table public.challenges enable row level security;
alter table public.challenge_members enable row level security;
alter table public.ai_usage enable row level security;

create or replace function public.my_ref() returns text language plpgsql security definer set search_path=public as $$
declare c text; begin
  if auth.uid() is null then raise exception 'auth'; end if;
  insert into profiles(user_id,ref_code) values(auth.uid(),upper(substr(md5(random()::text||auth.uid()::text),1,7))) on conflict(user_id) do nothing;
  select ref_code into c from profiles where user_id=auth.uid(); return c; end $$;

create or replace function public.redeem_ref(code text) returns boolean language plpgsql security definer set search_path=public as $$
declare inv uuid; begin
  perform public.my_ref();
  select user_id into inv from profiles where ref_code=upper(trim(code));
  if inv is null or inv=auth.uid() then return false; end if;
  if exists(select 1 from profiles where user_id=inv and referred_by=auth.uid()) then return false; end if;
  update profiles set referred_by=inv where user_id=auth.uid() and referred_by is null;
  return found; end $$;

create or replace function public.ref_count() returns int language sql security definer set search_path=public as
$$ select count(*)::int from profiles where referred_by=auth.uid() $$;

create or replace function public.ch_create(nm text) returns text language plpgsql security definer set search_path=public as $$
declare c text; cid uuid; begin
  if auth.uid() is null then raise exception 'auth'; end if;
  if (select count(*) from challenges where owner=auth.uid())>=3 then raise exception 'limit'; end if;
  c:=upper(substr(md5(random()::text||clock_timestamp()::text),1,6));
  insert into challenges(code,name,owner) values(c,left(nm,40),auth.uid()) returning id into cid;
  insert into challenge_members(challenge_id,user_id) values(cid,auth.uid());
  return c; end $$;

create or replace function public.ch_join(c text) returns boolean language plpgsql security definer set search_path=public as $$
declare cid uuid; begin
  if auth.uid() is null then raise exception 'auth'; end if;
  select id into cid from challenges where code=upper(trim(c));
  if cid is null then return false; end if;
  if (select count(*) from challenge_members where challenge_id=cid)>=50 then return false; end if;
  insert into challenge_members(challenge_id,user_id) values(cid,auth.uid()) on conflict do nothing;
  return true; end $$;

create or replace function public.ch_report(c text, s int, nm text) returns void language sql security definer set search_path=public as $$
  update challenge_members m set score=least(greatest(s,0),700), name=left(nm,24), updated_at=now()
  from challenges ch where ch.id=m.challenge_id and ch.code=upper(c) and m.user_id=auth.uid() $$;

create or replace function public.ch_board(c text) returns table(nm text, pts int) language plpgsql security definer set search_path=public as $$
begin
  if not exists(select 1 from challenge_members m join challenges ch on ch.id=m.challenge_id where ch.code=upper(c) and m.user_id=auth.uid()) then return; end if;
  return query select m.name,m.score from challenge_members m join challenges ch on ch.id=m.challenge_id where ch.code=upper(c) order by m.score desc limit 50; end $$;

create or replace function public.delete_me() returns void language plpgsql security definer set search_path=public,auth as $$
begin if auth.uid() is null then raise exception 'auth'; end if; delete from auth.users where id=auth.uid(); end $$;

create or replace function public.ai_bump(uid uuid, lim int, glim int) returns boolean language plpgsql security definer set search_path=public as $$
declare c int; g int; begin
  insert into ai_usage(user_id,day,n) values(uid,current_date,1) on conflict(user_id,day) do update set n=ai_usage.n+1 returning n into c;
  insert into ai_usage(user_id,day,n) values('00000000-0000-0000-0000-000000000000',current_date,1) on conflict(user_id,day) do update set n=ai_usage.n+1 returning n into g;
  return c<=lim and g<=glim; end $$;

-- Permissions
revoke all on function public.my_ref(),public.redeem_ref(text),public.ref_count(),public.ch_create(text),public.ch_join(text),public.ch_report(text,int,text),public.ch_board(text),public.delete_me(),public.ai_bump(uuid,int,int) from public,anon,authenticated;
grant execute on function public.my_ref(),public.redeem_ref(text),public.ref_count(),public.ch_create(text),public.ch_join(text),public.ch_report(text,int,text),public.ch_board(text),public.delete_me() to authenticated;
grant execute on function public.ai_bump(uuid,int,int) to service_role;
